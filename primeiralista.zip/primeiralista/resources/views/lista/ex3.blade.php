@extends('layout')

@section('conteudo')


<form method="post" action="listaex3">
    @csrf
    <div class="mb-3">
        <label for="temp1" class="form-label">Informe uma temperatura em Fahrenheit:</label>
        <input type="number" id="temp1" name="cel" class="form-control" required="">
    </div>

    <button type="submit" class="btn btn-primary">Enviar</button>
</form>

@isset($celsius)
    @isset($cel)
        <p>{{ $cel }}ºF em Celsius é {{ $celsius }}ºC</p>
    @endisset
@endisset

@endsection