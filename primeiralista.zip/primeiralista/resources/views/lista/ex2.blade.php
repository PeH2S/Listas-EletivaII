@extends('layout')

@section('conteudo')


<form method="post" action="listaex2">
    @csrf
    <div class="mb-3">
        <label for="temp1" class="form-label">Informe uma temperatura em Celsius:</label>
        <input type="number" id="temp1" name="temp1" class="form-control" required="">
    </div>

    <button type="submit" class="btn btn-primary">Enviar</button>
</form>

@isset($faren)
    @isset($temp1)
        <p>{{ $temp1 }}ºC em Fahrenheit é {{$faren}}ºF</p>
    @endisset
@endisset

@endsection