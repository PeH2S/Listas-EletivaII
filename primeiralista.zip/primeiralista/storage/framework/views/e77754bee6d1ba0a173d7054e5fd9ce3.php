

<?php $__env->startSection('conteudo'); ?>

<form method="post" action="listaex1">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
        <label for="nota1" class="form-label">Digite a primeira nota:</label>
        <input type="number" id="nota1" name="nota1" class="form-control" required="">
    </div>

    <div class="mb-3">
        <label for="nota2" class="form-label">Digite a segunda nota:</label>
        <input type="number" id="nota2" name="nota2" class="form-control" required="">
    </div>

    <div class="mb-3">
        <label for="nota3" class="form-label">Digite a terceira nota:</label>
        <input type="number" id="nota3" name="nota3" class="form-control" required="">
    </div>

    <button type="submit" class="btn btn-primary">Enviar</button>
</form>

<?php if(isset($media)): ?>
<p>A média é <?php echo e($media); ?></p>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Usuario\OneDrive - Fatec Centro Paula Souza\Desktop\ADS\PHP\Listas-EletivaII\primeiralista\resources\views/lista/ex1.blade.php ENDPATH**/ ?>