<ul>
    <li><a href="/exer1">Exercício 0</a></li>
    <li><a href="/ex1">Exercício 1</a></li>
    <li><a href="/ex2">Exercício 2</a></li>
    <li><a href="/ex3">Exercício 3</a></li>
    <li><a href="/ex4">Exercício 4</a></li>
    <li><a href="/ex5">Exercício 5</a></li>
    
</ul><?php /**PATH C:\Users\Usuario\OneDrive - Fatec Centro Paula Souza\Desktop\ADS\PHP\Listas-EletivaII\primeiralista\resources\views/cabecalho.blade.php ENDPATH**/ ?>