

<?php $__env->startSection('conteudo'); ?>


<form method="post" action="listaex3">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
        <label for="temp1" class="form-label">Informe uma temperatura em Fahrenheit:</label>
        <input type="number" id="temp1" name="cel" class="form-control" required="">
    </div>

    <button type="submit" class="btn btn-primary">Enviar</button>
</form>

<?php if(isset($celsius)): ?>
    <?php if(isset($cel)): ?>
        <p><?php echo e($cel); ?>ºF em Celsius é <?php echo e($celsius); ?>ºC</p>
    <?php endif; ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Usuario\OneDrive - Fatec Centro Paula Souza\Desktop\ADS\PHP\Listas-EletivaII\primeiralista\resources\views/lista/ex3.blade.php ENDPATH**/ ?>