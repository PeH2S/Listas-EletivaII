

<?php $__env->startSection('conteudo'); ?>


<form method="post" action="listaex4">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
        <label for="largura" class="form-label">Informe a Largura do Retângulo:</label>
        <input type="number" id="largura" name="largura" class="form-control" required="">
    </div>

    <div class="mb-3">
        <label for="altura" class="form-label">Informe a Altura do Retângulo:</label>
        <input type="number" id="altura" name="altura" class="form-control" required="">
    </div>

    <button type="submit" class="btn btn-primary">Enviar</button>
</form>

<?php if(isset($area)): ?>
    <p>A área do Retângulo é <?php echo e($area); ?></p>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Usuario\OneDrive - Fatec Centro Paula Souza\Desktop\ADS\PHP\Listas-EletivaII\primeiralista\resources\views/lista/ex4.blade.php ENDPATH**/ ?>