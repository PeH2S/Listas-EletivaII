<?php $__env->startSection('conteudo'); ?>

<form method="post" action="/exer1resp">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
        <label for="valor1" class="form-label">Informe o valor 1:</label>
        <input type="number" id="valor1" name="valor1" class="form-control" required="">
    </div>

    <div class="mb-3">
        <label for="valor2" class="form-label">Informe o valor 2:</label>
        <input type="number" id="valor2" name="valor2" class="form-control" required="">
    </div>

    <button type="submit" class="btn btn-primary">Enviar</button>

</form>

    <?php if(isset($soma)): ?>
        <p>O valor da soma é <?php echo e($soma); ?></p>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Usuario\OneDrive - Fatec Centro Paula Souza\Desktop\ADS\PHP\Listas-EletivaII\primeiralista\resources\views/exer1.blade.php ENDPATH**/ ?>