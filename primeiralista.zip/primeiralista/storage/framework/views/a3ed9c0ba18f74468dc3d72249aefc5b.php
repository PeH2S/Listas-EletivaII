

<?php $__env->startSection('conteudo'); ?>


<form method="post" action="listaex2">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
        <label for="temp1" class="form-label">Informe uma temperatura em Celsius:</label>
        <input type="number" id="temp1" name="temp1" class="form-control" required="">
    </div>

    <button type="submit" class="btn btn-primary">Enviar</button>
</form>

<?php if(isset($faren)): ?>
    <?php if(isset($temp1)): ?>
        <p><?php echo e($temp1); ?>ºC em Fahrenheit é <?php echo e($faren); ?>ºF</p>
    <?php endif; ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Usuario\OneDrive - Fatec Centro Paula Souza\Desktop\ADS\PHP\Listas-EletivaII\primeiralista\resources\views/lista/ex2.blade.php ENDPATH**/ ?>